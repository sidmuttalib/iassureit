<div class="yoast_newsletter_subscription messages warning">
  <h3><?php t('Yoast SEO Newsletter'); ?></h3>
  <p>
    <?php print t('Our newsletter contains loads of tips and tricks about how to optimize your SEO'); ?>.<br><br>
    <a href="http://yoast.us1.list-manage1.com/subscribe?u=ffa93edfe21752c921f860358&amp;id=c5c440d654" target="_blank" class="button"><?php print t('Subscribe here'); ?></a>
  </p>
</div>
